#Artist Theme: A Free Theme for Jekyll Sites

##Dependencies
1. Jekyll
2. Gulp
3. Sass
4. Jade
